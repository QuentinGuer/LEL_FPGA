#include "Matrice_bianire.hpp"
#include <cmath>


void afficherMatriceC(const ap_uint<LOG_COL_A> matrice[LIGNES_A][COLONNES_B]) {
    for (int i = 0; i < LIGNES_A; i++) {
        for (int j = 0; j < COLONNES_B; j++) {
            std::cout << matrice[i][j] << " ";
        }
        std::cout << std::endl;
    }
}

// Fonction pour g�n�rer un nombre flottant al�atoire entre -10 et 10
float generateurAleatoireFloat(ap_uint<1> min, ap_uint<1> max) {
    return min + static_cast<ap_uint<1>>(rand()) / (static_cast<ap_uint<1>>(RAND_MAX / (max - min)));
}

// Fonction pour remplir une matrice avec des valeurs al�atoires flottantes
void remplirMatriceAleatoire(ap_uint<1> matrice[LIGNES_A][COLONNES_A], ap_int<1> min, ap_int<1> max) {
    for (int i = 0; i < LIGNES_A; i++) {
        for (int j = 0; j < COLONNES_A; j++) {
            matrice[i][j] = generateurAleatoireFloat(min, max);
        }
    }
}

// Fonction pour remplir une deuxi�me matrice avec des valeurs al�atoires flottantes
void remplirMatriceAleatoireB(ap_uint<1> matrice[LIGNES_B][COLONNES_B], ap_int<1> min, ap_int<1> max) {
    for (int i = 0; i < LIGNES_B; i++) {
        for (int j = 0; j < COLONNES_B; j++) {
            matrice[i][j] = generateurAleatoireFloat(min, max);
        }
    }
}

// Fonction pour afficher une matrice
void afficherMatriceA(const ap_uint<1> matrice[LIGNES_A][COLONNES_A]) {
    for (int i = 0; i < LIGNES_A; i++) {
        for (int j = 0; j < COLONNES_A; j++) {
            std::cout << matrice[i][j] << " ";
        }
        std::cout << std::endl;
    }
}

// Fonction pour afficher une matrice
void afficherMatriceB(const ap_uint<1> matrice[LIGNES_B][COLONNES_B]) {
    for (int i = 0; i < LIGNES_B; i++) {
        for (int j = 0; j < COLONNES_B; j++) {
            std::cout << matrice[i][j] << " ";
        }
        std::cout << std::endl;
    }
}

int main()
{
	// D�finition des matrices statiques

    // Matrices � remplir avec des valeurs al�atoires
    ap_uint<1> matriceA[LIGNES_A][COLONNES_A];
    ap_uint<1> matriceB[LIGNES_B][COLONNES_B];

    // Remplir les matrices avec des nombres al�atoires entre -10 et 10
    remplirMatriceAleatoire(matriceA, 0, 1);
    remplirMatriceAleatoireB(matriceB, 0, 1);

	 // Matrice pour stocker le r�sultat
	 ap_uint<LOG_COL_A> matriceC[LIGNES_A][COLONNES_B]; // R�sultat de la multiplication
	 // Appel de la fonction pour multiplier les matrices
	 multmat(matriceA, matriceB, matriceC);



	 // Affichage de la matrice r�sultat
	 std::cout << "La matrice A est :" << std::endl;
	 afficherMatriceA(matriceA);
	 // Affichage de la matrice r�sultat
	 std::cout << "La matrice B est :" << std::endl;
	 afficherMatriceB(matriceB);

	 // Affichage de la matrice r�sultat
	 std::cout << "Le produit des matrices A et B est :" << std::endl;
	 afficherMatriceC(matriceC);


	 return 0;
}

#include "Matrice_bianire.hpp"
#include <iostream>
#include <cmath>

// Fonction pour multiplier deux matrices binaires
void multmat(const ap_uint<1> matriceA[LIGNES_A][COLONNES_A], const ap_uint<1> matriceB[LIGNES_B][COLONNES_B], ap_uint<LOG_COL_A> matriceC[LIGNES_A][COLONNES_B])
{
	ap_uint<LOG_COL_A> Entree = 0;
	ap_uint<LOG_COL_A> Entreetemp = 0;
    // Boucles imbriqu�es pour le calcul des produits matriciels
	multiplierMatrices_label6:for (short i = 0; i < LIGNES_A; i++)
	{
		multiplierMatrices_label7:for (short j = 0; j < COLONNES_B; j++)
		{
			matriceC[i][j] = 0;
			multmat_label0:for (short k = 0; k < COLONNES_A; k++)
			{
				Entree = matriceA[i][k] & matriceB[k][j];// Op�ration AND entre les �l�ments
				matriceC[i][j]+=Entree;// Somme accumul�e des produits
			}
		}
	}
}

// Variante de la multiplication de matrices pour des tailles diff�rentes
void multmat2(ap_uint<LOG_COL_A> matriceA[LIGNES_A][COLONNES_B], const ap_uint<1> matriceB[LIGNES_B][COLONNES_B], ap_uint<14> matriceC[LIGNES_B][COLONNES_B])
{
	ap_uint<14> Entree = 0;
	multiplierMatrices_label6:for (short i = 0; i < LIGNES_A; i++)
	{
		multiplierMatrices_label7:for (short j = 0; j < COLONNES_B; j++)
		{
			matriceC[i][j] = 0;
			multmat_label0:for (short k = 0; k < COLONNES_B; k++)
			{
				Entree = matriceA[i][k] & matriceB[k][j];
				matriceC[i][j]+=Entree;
			}
		}
	}
}

// Fonction pour appliquer une mise � l'�chelle (division par une puissance de 2)
void scale(ap_uint<14> matriceIN[LIGNES_B][COLONNES_B],type_sortie_scale_2pow_m14 matriceOUT[LIGNES_B][COLONNES_B])
{
	multiplierMatrices_label6:for (short i = 0; i < LIGNES_B; i++)
	{
		multiplierMatrices_label7:for (short j = 0; j < COLONNES_B; j++)
		{
			matriceOUT[i][j] = matriceIN[i][j]/8192;// Division par 2^13
		}
	}
}

// Bloc de calcul matriciel avec multiplication dense

//void BlocLinear(const ap_int<8> matriceA[DIMA][DIMA], const ap_uint<1> matriceB[LIGNES_B][COLONNES_B], ap_int<16> matriceC[LIGNES_B][COLONNES_B])
//void BlocLinear(const fixed_8 matriceA[DIMA][DIMA], const ap_uint<1> matriceB[LIGNES_B][COLONNES_B], fixed_16 matriceC[LIGNES_B][COLONNES_B])
void BlocLinear(const fixed_16 matriceA[DIMA][DIMA], const ap_uint<1> matriceB[LIGNES_B][COLONNES_B], fixed_24 matriceC[LIGNES_B][COLONNES_B])
//void BlocLinear(const int matriceA[DIMA][DIMA], const ap_uint<1> matriceB[LIGNES_B][COLONNES_B], int matriceC[LIGNES_B][COLONNES_B])
{
        // Multiplication des matrices
    for (short i = 0; i < DIMA; i++)
    {
        multmat_label1:for (short j = 0; j < COLONNES_B; j++)
        {
            matriceC[i][j] = 0;
            multmat_label0:for (short k = 0; k < DIMA; k++)
            {
                matriceC[i][j]+= matriceA[i][k]*matriceB[k][j];// Produit scalaire des lignes et colonnes
            }
        }
    }
}

// Version sp�cifique pour des matrices de dimensions 512xDIMA
void BlocLinear512(const fixed_16 matriceA[512][DIMA], const type_sortie_scale_2pow_m14 matriceB[LIGNES_B][COLONNES_B], fixed_24 matriceC[512][COLONNES_B])
//void BlocLinear(const int matriceA[DIMA][DIMA], const ap_uint<1> matriceB[LIGNES_B][COLONNES_B], int matriceC[LIGNES_B][COLONNES_B])
{
        // Multiplication des matrices
    for (short i = 0; i < 512; i++)
    {
        multmat_label1:for (short j = 0; j < COLONNES_B; j++)
        {
            matriceC[i][j] = 0;
            multmat_label0:for (short k = 0; k < DIMA; k++)
            {
                matriceC[i][j]+= matriceA[i][k]*matriceB[k][j];
            }
        }
    }
}

// Version sp�cifique pour des matrices de dimensions 256x512
void BlocLinear256(const fixed_16 matriceA[DIMA][512], const ap_uint<1> matriceB[512][COLONNES_B], fixed_24 matriceC[DIMA][COLONNES_B])
//void BlocLinear(const int matriceA[DIMA][DIMA], const ap_uint<1> matriceB[LIGNES_B][COLONNES_B], int matriceC[LIGNES_B][COLONNES_B])
{
        // Multiplication des matrices
    for (short i = 0; i < DIMA; i++)
    {
        multmat_label1:for (short j = 0; j < COLONNES_B; j++)
        {
            matriceC[i][j] = 0;
            multmat_label0:for (short k = 0; k < 512; k++)
            {
                matriceC[i][j]+= matriceA[i][k]*matriceB[k][j];
            }
        }
    }
}

// Fonction de mod�lisation LIF (Leaky Integrate-and-Fire)
void Lif(fixed_24 matricet[LIGNES_B][COLONNES_B], const fixed_24 matricet_1[LIGNES_B][COLONNES_B], ap_uint<1> spike[LIGNES_B][COLONNES_B])
{

	for (short i=0;i<LIGNES_B;i++)
	{
		Lif_label1:for(short j=0;j<COLONNES_B;j++)
		{
			matricet[i][j] = matricet_1[i][j]+matricet[i][j];
			spike[i][j] = matricet[i][j] > 15;
			matricet[i][j] = matricet[i][j]*(1-spike[i][j]);
		}
	}
}

// Version pour matrices 512xCOLONNES_B
void Lif512(fixed_24 matricet[512][COLONNES_B], const fixed_24 matricet_1[512][COLONNES_B], ap_uint<1> spike[512][COLONNES_B])
{

	for (short i=0;i<LIGNES_B;i++)
	{
		Lif_label1:for(short j=0;j<COLONNES_B;j++)
		{
			matricet[i][j] = matricet_1[i][j]+matricet[i][j];
			spike[i][j] = matricet[i][j] > 15;// Seuil de spike
			matricet[i][j] = matricet[i][j]*(1-spike[i][j]);// Reset apr�s spike
		}
	}
}

// Fonction pour transposer une matrice
void transposeMatrix(ap_uint<1> input[LIGNES_B][COLONNES_B], ap_uint<1> output[LIGNES_A][COLONNES_A])
{
    for (short i = 0; i < LIGNES_B; i++)
    {
        transposeMatrix_label0:for (short j = 0; j < COLONNES_B; j++)
        {
            output[j][i] = input[i][j];// �change de lignes et colonnes
        }
    }
}

// Fonction principale pour une suite de calculs de type attention
void Elements(const ap_uint<1> EntreeQ[LIGNES_B][COLONNES_B], const fixed_16 poidsQ1[DIMA][DIMA],const fixed_16 poidsQ2[DIMA][DIMA],const fixed_16 poidsQ3[DIMA][DIMA],const fixed_16 poidsQ4[DIMA][DIMA],const fixed_16 poidsQ5[DIMA][DIMA],const fixed_16 poidsQ6[DIMA][DIMA],
        	  const ap_uint<1> EntreeK[LIGNES_B][COLONNES_B], const fixed_16 poidsK1[DIMA][DIMA],const fixed_16 poidsK2[DIMA][DIMA],const fixed_16 poidsK3[DIMA][DIMA],const fixed_16 poidsK4[DIMA][DIMA],const fixed_16 poidsK5[DIMA][DIMA],const fixed_16 poidsK6[DIMA][DIMA],
			  const ap_uint<1> EntreeV[LIGNES_B][COLONNES_B], const fixed_16 poidsV1[DIMA][DIMA],const fixed_16 poidsV2[DIMA][DIMA],const fixed_16 poidsV3[DIMA][DIMA],const fixed_16 poidsV4[DIMA][DIMA],const fixed_16 poidsV5[DIMA][DIMA],const fixed_16 poidsV6[DIMA][DIMA],
			  const fixed_16 poids512[512][DIMA], const fixed_16 poids256[DIMA][DIMA], ap_uint<1> Sortie[LIGNES_B][COLONNES_B])
{
	//const fixed_16 (*poidsQ[6])[DIMA] = {poidsQ1, poidsQ2, poidsQ3, poidsQ4, poidsQ5, poidsQ6};
	//const fixed_16 (*poidsK[6])[DIMA] = {poidsK1, poidsK2, poidsK3, poidsK4, poidsK5, poidsK6};
	//const fixed_16 (*poidsV[6])[DIMA] = {poidsV1, poidsV2, poidsV3, poidsV4, poidsV5, poidsV6};


	// Les variables interm�diaires pour le calcul
	fixed_24 DenseQ[LIGNES_B][COLONNES_B];
	fixed_24 DenseK[LIGNES_B][COLONNES_B];
	fixed_24 DenseV[LIGNES_B][COLONNES_B];

	fixed_24 DenseQt_1[LIGNES_B][COLONNES_B];
	fixed_24 DenseKt_1[LIGNES_B][COLONNES_B];
	fixed_24 DenseVt_1[LIGNES_B][COLONNES_B];

	ap_uint<1> spikeQ[LIGNES_B][COLONNES_B];
	ap_uint<1> spikeK[LIGNES_B][COLONNES_B];
	ap_uint<1> spikeKT[LIGNES_A][COLONNES_A];
	ap_uint<1> spikeV[LIGNES_B][COLONNES_B];

	ap_uint<LOG_COL_A> multmat1[LIGNES_A][COLONNES_B];
	ap_uint<14> Attention[LIGNES_B][COLONNES_B];

	type_sortie_scale_2pow_m14 OUTScale[LIGNES_B][COLONNES_B];

	fixed_24 Dense512[512][COLONNES_B];
	fixed_24 Dense512t_1[512][COLONNES_B];

	fixed_24 Dense256[256][COLONNES_B];
	fixed_24 Dense256t_1[256][COLONNES_B];

	ap_uint<1> spike512[512][COLONNES_B];
	//ap_uint<1> spike256[256][COLONNES_B];

	// Calcul pour chaque bloc de poids
	BlocLinear(poidsQ1, EntreeQ, DenseQ);
	BlocLinear(poidsK1, EntreeK, DenseK);
	BlocLinear(poidsV1, EntreeV, DenseV);

	Lif(DenseQ, DenseQt_1, spikeQ);
	Lif(DenseK, DenseKt_1, spikeK);
	Lif(DenseV, DenseVt_1, spikeV);

	transposeMatrix(spikeK, spikeKT);

	multmat(spikeKT, spikeQ, multmat1);

	multmat2(multmat1, spikeV, Attention);

	scale(Attention, OUTScale);

	BlocLinear512(poids512, OUTScale, Dense512);

	Lif512(Dense512, Dense512t_1, spike512);

	BlocLinear(poids256, spike512, Dense256);

	Lif(Dense256, Dense256t_1, Sortie);

	BlocLinear(poidsQ2, EntreeQ, DenseQ);
	BlocLinear(poidsK2, EntreeK, DenseK);
	BlocLinear(poidsV2, EntreeV, DenseV);

	Lif(DenseQ, DenseQt_1, spikeQ);
	Lif(DenseK, DenseKt_1, spikeK);
	Lif(DenseV, DenseVt_1, spikeV);

	transposeMatrix(spikeK, spikeKT);

	multmat(spikeKT, spikeQ, multmat1);

	multmat2(multmat1, spikeV, Attention);

	scale(Attention, OUTScale);

	BlocLinear512(poids512, OUTScale, Dense512);

	Lif512(Dense512, Dense512t_1, spike512);

	BlocLinear(poids256, spike512, Dense256);

	Lif(Dense256, Dense256t_1, Sortie);



	BlocLinear(poidsQ3, EntreeQ, DenseQ);
	BlocLinear(poidsK3, EntreeK, DenseK);
	BlocLinear(poidsV3, EntreeV, DenseV);

	Lif(DenseQ, DenseQt_1, spikeQ);
	Lif(DenseK, DenseKt_1, spikeK);
	Lif(DenseV, DenseVt_1, spikeV);

	transposeMatrix(spikeK, spikeKT);

	multmat(spikeKT, spikeQ, multmat1);

	multmat2(multmat1, spikeV, Attention);

	scale(Attention, OUTScale);

	BlocLinear512(poids512, OUTScale, Dense512);

	Lif512(Dense512, Dense512t_1, spike512);

	BlocLinear(poids256, spike512, Dense256);

	Lif(Dense256, Dense256t_1, Sortie);




	BlocLinear(poidsQ4, EntreeQ, DenseQ);
	BlocLinear(poidsK4, EntreeK, DenseK);
	BlocLinear(poidsV4, EntreeV, DenseV);

	Lif(DenseQ, DenseQt_1, spikeQ);
	Lif(DenseK, DenseKt_1, spikeK);
	Lif(DenseV, DenseVt_1, spikeV);

	transposeMatrix(spikeK, spikeKT);

	multmat(spikeKT, spikeQ, multmat1);

	multmat2(multmat1, spikeV, Attention);

	scale(Attention, OUTScale);

	BlocLinear512(poids512, OUTScale, Dense512);

	Lif512(Dense512, Dense512t_1, spike512);

	BlocLinear(poids256, spike512, Dense256);

	Lif(Dense256, Dense256t_1, Sortie);



	BlocLinear(poidsQ5, EntreeQ, DenseQ);
	BlocLinear(poidsK5, EntreeK, DenseK);
	BlocLinear(poidsV5, EntreeV, DenseV);

	Lif(DenseQ, DenseQt_1, spikeQ);
	Lif(DenseK, DenseKt_1, spikeK);
	Lif(DenseV, DenseVt_1, spikeV);

	transposeMatrix(spikeK, spikeKT);

	multmat(spikeKT, spikeQ, multmat1);

	multmat2(multmat1, spikeV, Attention);

	scale(Attention, OUTScale);

	BlocLinear512(poids512, OUTScale, Dense512);

	Lif512(Dense512, Dense512t_1, spike512);

	BlocLinear(poids256, spike512, Dense256);

	Lif(Dense256, Dense256t_1, Sortie);




	BlocLinear(poidsQ6, EntreeQ, DenseQ);
	BlocLinear(poidsK6, EntreeK, DenseK);
	BlocLinear(poidsV6, EntreeV, DenseV);

	Lif(DenseQ, DenseQt_1, spikeQ);
	Lif(DenseK, DenseKt_1, spikeK);
	Lif(DenseV, DenseVt_1, spikeV);

	transposeMatrix(spikeK, spikeKT);

	multmat(spikeKT, spikeQ, multmat1);

	multmat2(multmat1, spikeV, Attention);

	scale(Attention, OUTScale);

	BlocLinear512(poids512, OUTScale, Dense512);

	Lif512(Dense512, Dense512t_1, spike512);

	BlocLinear(poids256, spike512, Dense256);

	Lif(Dense256, Dense256t_1, Sortie);


}


#include "ap_int.h"
#include "ap_fixed.h"
#include <iostream>
#include <cmath>



//#define LIGNES_A  3 // Nombre de lignes de la matrice A
//#define COLONNES_A  2 // Nombre de colonnes de la matrice A
//#define LIGNES_B  2 // Nombre de lignes de la matrice B (doit �tre �gal � COLONNES_A)
//#define COLONNES_B  3

//#define LIGNES_A  2 // Nombre de lignes de la matrice A
//#define COLONNES_A  16 // Nombre de colonnes de la matrice A
//#define LIGNES_B  16 // Nombre de lignes de la matrice B (doit �tre �gal � COLONNES_A)
//#define COLONNES_B  2
//#define LOG_COL_A 5  //Log2 arrondi au sup�rieur de la valeur de la col A ou de la ligne B



#define LIGNES_A  32 // Nombre de lignes de la matrice A
#define COLONNES_A  256 // Nombre de colonnes de la matrice A
#define LIGNES_B  256 // Nombre de lignes de la matrice B (doit �tre �gal � COLONNES_A)
#define COLONNES_B  32
#define LOG_COL_A 9  //Log2 arrondi au sup�rieur de la valeur de la col A ou de la ligne B

#define DIMA  256 // Nombre de lignes de la matrice A (doit �tre �gal � COLONNES_A)

// D�claration de la matrice avec le type ap_fixed<16, 8>  16 bits donc 8 bits de parti entiere
typedef ap_fixed<16, 8> fixed_16;
// D�claration de la matrice avec le type ap_fixed<16, 16>
typedef ap_fixed<24,16> fixed_24;
// D�claration de la matrice avec le type ap_fixed<8, 4>
typedef ap_fixed<8,4> fixed_8;

typedef ap_fixed<14,0> type_sortie_scale_2pow_m14;


//#define LIGNES_A  64 // Nombre de lignes de la matrice A
//#define COLONNES_A  512 // Nombre de colonnes de la matrice A
//#define LIGNES_B  512 // Nombre de lignes de la matrice B (doit �tre �gal � COLONNES_A)
//#define COLONNES_B  64
//#define LOG_COL_A 10 //Log2 arrondi au sup�rieur de la valeur de la col A ou de la ligne B

//#define LIGNES_A  128 // Nombre de lignes de la matrice A
//#define COLONNES_A  768 // Nombre de colonnes de la matrice A
//#define LIGNES_B  768 // Nombre de lignes de la matrice B (doit �tre �gal � COLONNES_A)
//#define COLONNES_B  128
//#define LOG_COL_A 10 //Log2 arrondi au sup�rieur de la valeur de la col A ou de la ligne B


void multmat(const ap_uint<1> matriceA[LIGNES_A][COLONNES_A], const ap_uint<1> matriceB[LIGNES_B][COLONNES_B], ap_uint<LOG_COL_A> matriceC[LIGNES_A][COLONNES_B]);

